package com.healthyeating

import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Route.registerRoutes() {
    post("/register") {
        val request = call.receive<RegisterRequest>()

        val existingUser = Storage.users.find { it.email == request.email }
        if (existingUser != null) {
            call.respond(
                HttpStatusCode.BadRequest,
                MessageResponse("Email already exists")
            )
            return@post
        }

        val newUser = User(
            id = Storage.userIdCounter++,
            username = request.username,
            email = request.email,
            password = request.password,
            role = request.role
        )

        Storage.users.add(newUser)

        val response = RegisterResponse(
            id = newUser.id,
            username = newUser.username,
            email = newUser.email,
            role = newUser.role
        )

        call.respond(HttpStatusCode.Created, response)
    }
}