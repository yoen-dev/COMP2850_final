package com.healthyeating

import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Route.foodDiaryRoutes() {
    post("/food-diary") {
        val request = call.receive<FoodDiaryRequest>()

        val userExists = Storage.users.any { it.id == request.userId }
        if (!userExists) {
            call.respond(
                HttpStatusCode.BadRequest,
                MessageResponse("User not found")
            )
            return@post
        }

        val newRecord = FoodDiaryResponse(
            id = Storage.foodDiaryIdCounter++,
            userId = request.userId,
            foodName = request.foodName,
            quantity = request.quantity,
            date = request.date,
            calories = request.calories
        )

        Storage.foodDiaries.add(newRecord)

        call.respond(HttpStatusCode.Created, newRecord)
    }

    get("/food-diary") {
        call.respond(HttpStatusCode.OK, Storage.foodDiaries)
    }

    put("/food-diary/{id}") {
        val id = call.parameters["id"]?.toIntOrNull()
        if (id == null) {
            call.respond(HttpStatusCode.BadRequest, MessageResponse("Invalid ID"))
            return@put
        }

        val request = call.receive<UpdateFoodDiaryRequest>()
        val index = Storage.foodDiaries.indexOfFirst { it.id == id }

        if (index == -1) {
            call.respond(HttpStatusCode.NotFound, MessageResponse("Food diary record not found"))
            return@put
        }

        val oldRecord = Storage.foodDiaries[index]
        val updatedRecord = oldRecord.copy(
            foodName = request.foodName,
            quantity = request.quantity,
            date = request.date,
            calories = request.calories
        )

        Storage.foodDiaries[index] = updatedRecord

        call.respond(HttpStatusCode.OK, updatedRecord)
    }

    delete("/food-diary/{id}") {
        val id = call.parameters["id"]?.toIntOrNull()
        if (id == null) {
            call.respond(HttpStatusCode.BadRequest, MessageResponse("Invalid ID"))
            return@delete
        }

        val removed = Storage.foodDiaries.removeIf { it.id == id }

        if (!removed) {
            call.respond(HttpStatusCode.NotFound, MessageResponse("Food diary record not found"))
            return@delete
        }

        call.respond(HttpStatusCode.OK, MessageResponse("Food diary record deleted successfully"))
    }
}