package com.healthyeating

import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Route.loginRoutes() {
    post("/login") {
        val request = call.receive<LoginRequest>()

        val user = Storage.users.find {
            it.email == request.email && it.password == request.password
        }

        if (user != null) {
            val response = LoginResponse(
                message = "Login successful",
                email = user.email,
                role = user.role
            )
            call.respond(HttpStatusCode.OK, response)
        } else {
            call.respond(
                HttpStatusCode.Unauthorized,
                MessageResponse("Invalid email or password")
            )
        }
    }
}