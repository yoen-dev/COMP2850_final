package com.healthyeating

import kotlinx.serialization.Serializable

@Serializable
data class MessageResponse(
    val message: String
)

@Serializable
data class RegisterRequest(
    val username: String,
    val email: String,
    val password: String,
    val role: String = "subscriber"
)

@Serializable
data class RegisterResponse(
    val id: Int,
    val username: String,
    val email: String,
    val role: String
)

@Serializable
data class LoginRequest(
    val email: String,
    val password: String
)

@Serializable
data class LoginResponse(
    val message: String,
    val email: String,
    val role: String
)

@Serializable
data class FoodDiaryRequest(
    val userId: Int,
    val foodName: String,
    val quantity: String,
    val date: String,
    val calories: Int
)

@Serializable
data class FoodDiaryResponse(
    val id: Int,
    val userId: Int,
    val foodName: String,
    val quantity: String,
    val date: String,
    val calories: Int
)

@Serializable
data class User(
    val id: Int,
    val username: String,
    val email: String,
    val password: String,
    val role: String
)

@Serializable
data class UpdateFoodDiaryRequest(
    val foodName: String,
    val quantity: String,
    val date: String,
    val calories: Int
)
