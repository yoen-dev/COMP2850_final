package com.healthyeating

object Storage {
    val users = mutableListOf<User>()
    val foodDiaries = mutableListOf<FoodDiaryResponse>()

    var userIdCounter = 1
    var foodDiaryIdCounter = 1
}