package com.healthyeating

import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.statuspages.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun main() {
    embeddedServer(Netty, port = 8080, host = "0.0.0.0") {
        module()
    }.start(wait = true)
}

fun Application.module() {
    install(ContentNegotiation) {
        json()
    }

    install(StatusPages) {
        exception<Throwable> { call, cause ->
            call.respond(
                HttpStatusCode.InternalServerError,
                MessageResponse("Server error: ${cause.message}")
            )
        }
    }

    routing {
        get("/") {
            call.respond(MessageResponse("Ktor backend is running"))
        }

        get("/health") {
            call.respond(MessageResponse("OK"))
        }

        registerRoutes()
        loginRoutes()
        foodDiaryRoutes()
    }
}